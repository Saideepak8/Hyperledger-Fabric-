/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

public class ExpectedException extends RuntimeException {
    public ExpectedException(final String message) {
        super(message);
    }
}
